import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Depoimentos(){
  const testimonials = [
    {name: 'Mariana S.', text: 'Incrível! A Braso transformou nosso almoço de equipe.'},
    {name: 'Carlos P.', text: 'Sabor e apresentação impecáveis. Recomendamos!'},
    {name: 'Ana R.', text: 'As geleias foram o diferencial. Nossos convidados amaram.'}
  ];
  return (
    <>
      <Head>
        <title>Depoimentos — Braso Taste</title>
        <meta name="description" content="Depoimentos de clientes satisfeitos com as experiências Braso Taste." />
      </Head>
      <Header />
      <main className="container py-16">
        <h1 className="text-3xl font-extrabold">Depoimentos</h1>
        <div className="mt-6 grid md:grid-cols-3 gap-4">
          {testimonials.map((t, i) => (
            <blockquote key={i} className="p-6 border rounded-2xl bg-white shadow-sm">
              <p className="text-neutral-700">"{t.text}"</p>
              <footer className="mt-3 text-sm font-semibold">— {t.name}</footer>
            </blockquote>
          ))}
        </div>
      </main>
      <Footer />
    </>
  )
}