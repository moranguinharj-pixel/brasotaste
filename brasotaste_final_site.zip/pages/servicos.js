import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Servicos(){
  return (
    <>
      <Head>
        <title>Serviços — Braso Taste</title>
        <meta name="description" content="Serviços: café da manhã, brunch, almoço, jantar, festas privadas e eventos corporativos. Cardápio personalizado e experiência a domicílio." />
      </Head>
      <Header />
      <main className="container py-16">
        <h1 className="text-3xl font-extrabold">Serviços para cada momento</h1>
        <p className="mt-3 text-neutral-700 max-w-2xl">Co-criamos menus sob medida para cada ocasião, sempre priorizando apresentação, sabor e memória afetiva.</p>

        <section className="mt-8 grid md:grid-cols-2 gap-6">
          <article className="p-6 border rounded-2xl">
            <h3 className="font-bold">Café da manhã & Brunch</h3>
            <p className="mt-2 text-sm text-neutral-700">Pães artesanais, geleias Braso, queijos e opções frescas.</p>
          </article>
          <article className="p-6 border rounded-2xl">
            <h3 className="font-bold">Almoço & Jantar</h3>
            <p className="mt-2 text-sm text-neutral-700">Carnes defumadas, frutos do mar, legumes grelhados e harmonizações.</p>
          </article>
          <article className="p-6 border rounded-2xl">
            <h3 className="font-bold">Festas Privadas</h3>
            <p className="mt-2 text-sm text-neutral-700">Apresentação premium e experiência completa para celebrar.</p>
          </article>
          <article className="p-6 border rounded-2xl">
            <h3 className="font-bold">Eventos Corporativos</h3>
            <p className="mt-2 text-sm text-neutral-700">Soluções práticas e sofisticadas para reuniões e confraternizações.</p>
          </article>
        </section>
      </main>
      <Footer />
    </>
  )
}