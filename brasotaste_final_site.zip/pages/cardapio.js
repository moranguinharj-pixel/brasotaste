import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Cardapio(){
  return (
    <>
      <Head>
        <title>Cardápio — Braso Taste</title>
        <meta name="description" content="Cardápio Braso Taste: carnes premium defumadas, frutos do mar na brasa, legumes grelhados, brioche artesanal e geleias da casa." />
      </Head>
      <Header />
      <main className="container py-16">
        <h1 className="text-3xl font-extrabold">Cardápio</h1>
        <p className="mt-4 text-neutral-700">Exemplos de itens (personalizáveis):</p>
        <ul className="mt-4 list-disc ml-6 space-y-2">
          <li>Costela suína defumada</li>
          <li>Cupim defumado</li>
          <li>Brisket defumado</li>
          <li>Picanha na brasa</li>
          <li>Camarões na brasa</li>
          <li>Legumes grelhados e defumados</li>
          <li>Brioche artesanal da @panificacao_viçosa</li>
          <li>Geleias da casa Braso (vários sabores)</li>
          <li>Sobremesas na brasa</li>
        </ul>
      </main>
      <Footer />
    </>
  )
}