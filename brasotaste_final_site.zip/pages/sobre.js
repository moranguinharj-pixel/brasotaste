import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Sobre(){
  return (
    <>
      <Head>
        <title>Sobre — Braso Taste</title>
        <meta name="description" content="A Braso Taste transforma churrasco premium em experiências afetivas a domicílio, conectando alta gastronomia com memória gustativa." />
      </Head>
      <Header />
      <main className="container py-16">
        <h1 className="text-3xl font-extrabold">Sobre a Braso Taste</h1>
        <p className="mt-4 text-neutral-700">A Braso Taste nasceu para levar o sabor irresistível da brasa até o cliente, ligando alta gastronomia com culinária sensorial afetiva. Criamos cardápios personalizados para café da manhã, brunch, almoço, jantar, festas e eventos corporativos — sempre focando em experiências memoráveis à mesa.</p>
        <h2 className="mt-8 text-2xl font-bold">Nosso diferencial</h2>
        <ul className="mt-3 list-disc ml-6 text-neutral-700">
          <li>Defumação artesanal e técnicas de maçaricação</li>
          <li>Geleias artesanais Braso para harmonização</li>
          <li>Parcerias com fornecedores premium (brioche, queijos)</li>
          <li>Personalização e serviço a domicílio</li>
        </ul>
      </main>
      <Footer />
    </>
  )
}