import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Contato(){
  const contact = {"@context": "https://schema.org", "@type": "ContactPoint", "telephone": "+5521974064098", "contactType": "customer service", "email": "contato@brasotaste.com.br", "areaServed": "BR"};
  return (
    <>
      <Head>
        <title>Contato — Braso Taste</title>
        <meta name="description" content="Solicite proposta para eventos, encomendas e parcerias. Braso Taste — churrasco premium a domicílio." />
        <script type="application/ld+json">{JSON.stringify(contact)}</script>
      </Head>
      <Header />
      <main className="container py-16 grid md:grid-cols-2 gap-8">
        <div>
          <h1 className="text-3xl font-extrabold">Vamos criar sua experiência?</h1>
          <p className="mt-3 text-neutral-700">Conte sobre seu evento (data, local, nº de pessoas, preferências) e receba uma proposta personalizada.</p>
          <ul className="mt-6 text-sm text-neutral-700 space-y-2">
            <li>WhatsApp: <a href="https://wa.me/5521974064098" className="text-braso">+5521974064098</a></li>
            <li>E-mail: contato@brasotaste.com.br</li>
            <li>Instagram: <a href="https://instagram.com/brasotaste" target="_blank" rel="noreferrer">@brasotaste</a></li>
          </ul>
        </div>
        <form className="bg-white rounded-2xl p-6 shadow" onSubmit={(e)=>{ e.preventDefault(); alert('Enviado! (a implementar)') }}>
          <label className="block">
            <span className="text-sm">Nome</span>
            <input className="mt-1 w-full rounded-xl border px-3 py-2" required />
          </label>
          <label className="block mt-3">
            <span className="text-sm">E-mail</span>
            <input type="email" className="mt-1 w-full rounded-xl border px-3 py-2" required />
          </label>
          <label className="block mt-3">
            <span className="text-sm">Tipo de evento</span>
            <select className="mt-1 w-full rounded-xl border px-3 py-2">
              <option>Almoço</option>
              <option>Jantar</option>
              <option>Brunch</option>
              <option>Evento corporativo</option>
            </select>
          </label>
          <label className="block mt-3">
            <span className="text-sm">Mensagem</span>
            <textarea className="mt-1 w-full rounded-xl border px-3 py-2" rows={5}></textarea>
          </label>
          <button className="mt-4 w-full bg-braso text-white px-4 py-3 rounded-2xl">Solicitar proposta</button>
        </form>
      </main>
      <Footer />
    </>
  )
}
