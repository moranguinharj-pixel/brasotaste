import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Eventos(){
  const event = {"@context": "https://schema.org", "@type": "Event", "name": "Experiência Braso Taste - Evento Privado", "startDate": "2025-09-01", "location": {"@type": "Place", "name": "Local do cliente", "address": {"@type": "PostalAddress", "addressLocality": "Rio de Janeiro", "addressRegion": "RJ"}}, "description": "Experiência gastronômica personalizada com carnes defumadas, geleias Braso e harmonizações."};
  return (
    <>
      <Head>
        <title>Eventos — Braso Taste</title>
        <meta name="description" content="Eventos: casamentos, aniversários, jantares empresariais e confraternizações com cardápio personalizado a domicílio." />
        <script type="application/ld+json">{JSON.stringify(event)}</script>
      </Head>
      <Header />
      <main className="container py-16">
        <h1 className="text-3xl font-extrabold">Eventos personalizados</h1>
        <p className="mt-4 text-neutral-700">Organizamos experiências completas: menu sob medida, equipe no local e apresentação premium.</p>
        <h2 className="mt-8 text-2xl font-bold">Tipos de eventos</h2>
        <ul className="mt-3 list-disc ml-6">
          <li>Casamentos e confraternizações</li>
          <li>Aniversários e celebrações familiares</li>
          <li>Jantares corporativos e lançamentos</li>
        </ul>
      </main>
      <Footer />
    </>
  )
}
