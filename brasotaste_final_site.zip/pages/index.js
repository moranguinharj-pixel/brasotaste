import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'
import Hero from '../components/Hero'

export default function Home(){
  return (
    <>
<Head>
<title>Braso Taste — Churrasco Premium a Domicílio | Rio de Janeiro</title>
<meta name="description" content="Braso Taste leva o sabor irresistível da brasa até você: café da manhã, brunch, almoço, jantar, festas e eventos corporativos. Cardápio personalizado e experiência sensorial afetiva." />
<meta property="og:title" content="Braso Taste – BBQ & Gastronomic Experience at Home" />
<meta property="og:description" content="Churrasco premium, cardápio personalizado e experiência sensorial afetiva a domicílio." />
<meta property="og:image" content="/og.jpg" />
<script type="application/ld+json">{"@context": "https://schema.org", "@type": "Caterer", "name": "Braso Taste", "alternateName": "Braso Taste – BBQ & Gastronomic Experience at Home", "url": "https://www.brasotaste.com.br", "logo": "https://www.brasotaste.com.br/logo.svg", "image": "https://www.brasotaste.com.br/og.jpg", "telephone": "+5521974064098", "email": "contato@brasotaste.com.br", "address": {"@type": "PostalAddress", "addressLocality": "Rio de Janeiro", "addressRegion": "RJ", "addressCountry": "BR"}, "sameAs": ["https://www.instagram.com/brasotaste"], "areaServed": "Rio de Janeiro e região metropolitana", "servesCuisine": ["BBQ", "Churrasco premium", "Gastronomia contemporânea"], "slogan": "BBQ & Gastronomic Experience at Home", "priceRange": "$$ – $$$"}</script>
<script type="application/ld+json">{"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": "Quais tipos de eventos?", "acceptedAnswer": {"@type": "Answer", "text": "Café da manhã, brunch, almoço, jantar, festas e eventos corporativos com cardápio personalizado."}}, {"@type": "Question", "name": "Área de atendimento?", "acceptedAnswer": {"@type": "Answer", "text": "Rio de Janeiro e região metropolitana."}}]}</script>
</Head>
      <Header />
      <main>
        <Hero />

        <section className="container py-16">
          <h2 className="text-2xl font-extrabold">Serviços</h2>
          <p className="mt-2 text-neutral-700 max-w-2xl">Co-criamos o menu ideal para cada ocasião — do brunch ao jantar corporativo.</p>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <article className="p-6 border rounded-2xl">
              <h3 className="font-bold">Cardápios personalizados</h3>
              <p className="mt-2 text-sm text-neutral-700">Menus sob medida considerando restrições e preferências.</p>
            </article>
            <article className="p-6 border rounded-2xl">
              <h3 className="font-bold">Execução no local</h3>
              <p className="mt-2 text-sm text-neutral-700">Equipe preparada para montagem e serviço com apresentação premium.</p>
            </article>
            <article className="p-6 border rounded-2xl">
              <h3 className="font-bold">Delivery gourmet</h3>
              <p className="mt-2 text-sm text-neutral-700">Kits e refeições embaladas com cuidado para manter temperatura e apresentação.</p>
            </article>
          </div>
        </section>

      </main>

      <Footer />
    </>
  )
}
