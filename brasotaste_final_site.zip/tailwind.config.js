module.exports = {
  content: ['./pages/**/*.{js,jsx}','./components/**/*.{js,jsx}'],
  theme: { extend: { colors: { braso: '#D97706' } } },
  plugins: []
}